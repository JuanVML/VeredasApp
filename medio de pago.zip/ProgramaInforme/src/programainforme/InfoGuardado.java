package programainforme;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Ruiz Polo, Ericka Yadira
 */
public class InfoGuardado extends javax.swing.JFrame { 
        DefaultTableModel dtm = new DefaultTableModel();
    public InfoGuardado() {
        initComponents();
        this.setSize(900, 650);
        this.setLocationRelativeTo(null);
        String[] titulo = new String[] {"Nombres", "Apellidos", "Teléfono", "DNI", "Género", "Inicio de la Obra", "Fin de la Obra", "Estado de la Obra"};
        dtm.setColumnIdentifiers(titulo);
        tablaInfo.setModel(dtm);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaInfo = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnPDF = new javax.swing.JButton();
        btnRegresar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaInfo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tablaInfo);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 820, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("DATOS REGISTRADOS");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 820, -1));

        btnPDF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/PDF.png"))); // NOI18N
        btnPDF.setToolTipText("");
        btnPDF.setBorderPainted(false);
        btnPDF.setContentAreaFilled(false);
        btnPDF.setDefaultCapable(false);
        btnPDF.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/img/PDF (1).png"))); // NOI18N
        btnPDF.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/img/PDF (1).png"))); // NOI18N
        getContentPane().add(btnPDF, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 510, -1, -1));

        btnRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Regresar.png"))); // NOI18N
        btnRegresar.setToolTipText("");
        btnRegresar.setBorderPainted(false);
        btnRegresar.setContentAreaFilled(false);
        btnRegresar.setDefaultCapable(false);
        btnRegresar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Regresar (1).png"))); // NOI18N
        btnRegresar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Regresar (1).png"))); // NOI18N
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 510, -1, -1));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar.png"))); // NOI18N
        btnBuscar.setToolTipText("");
        btnBuscar.setBorderPainted(false);
        btnBuscar.setContentAreaFilled(false);
        btnBuscar.setDefaultCapable(false);
        btnBuscar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar (1).png"))); // NOI18N
        btnBuscar.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Buscar (1).png"))); // NOI18N
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 510, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    public static void main(String args[]) {
        new InfoGuardado();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaInfo;
    // End of variables declaration//GEN-END:variables
}
